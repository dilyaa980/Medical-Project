import React from "react";
import "./Directions.scss";

const Directions = () => {
  return (
    <div className="container">
      <div className="Directions">
        <div className="box">
          <div className="card-title">Онкология</div>
          <div className="subdirections">
            <p>• Рак груди </p>
            <p>• Рак простаты </p>
            <p>• Рак легких</p>
            <p>• Меланома</p>
            <p>• Рак желудка</p>
            <p> • Рак поджелудочной железы</p>
          </div>
          <div className="Button_show">
            <button className="btn-show">Показать все клиники</button>
          </div>
        </div>
        <div className="box">
          <div className="card-title">Check Up</div>
          <div className="subdirections">
            <p>• Мужская </p>
            <p> • Женская </p>
            <p> • Детская </p>
            <p>• Специализированная</p>
          </div>{" "}
          <div className="Button_show">
            <button className="btn-show">Показать все клиники</button>
          </div>
        </div>
        <div className="box">
          <div className="card-title">Красота</div>
          <div className="subdirections">
            <p>• Увеличение груди</p> <p>• Абдоминопластика </p>
            <p>• Anti age </p> <p>• Блефаропластика</p>
          </div>
          <div className="Button_show">
            <button className="btn-show">Показать все клиники</button>
          </div>
        </div>
        <div className="box">
          <div className="card-title">Медицина будущего </div>
          <div className="subdirections">
            <p>• Лечение стволовыми</p>
            <p>• ДНК тест </p>
            <p>• Определение рака по моче</p>
          </div>
          <div className="Button_show">
            <button className="btn-show">Показать все клиники</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Directions;
