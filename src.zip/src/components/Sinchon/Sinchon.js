import React from 'react'

const Sinchon = () => {
  return (
    <div>
        <h4> Sinchon</h4>
       
    </div>
  )
}

export default Sinchon