import React from "react";

const Contacts= () => {
  return <div></div>;
};

export default Contacts;
