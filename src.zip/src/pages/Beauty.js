import React from "react";

const Beauty= () => {
  return <div></div>;
};

export default Beauty;
