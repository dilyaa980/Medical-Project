import React from "react";

const Medicine = () => {
  return <div></div>;
};

export default Medicine;
