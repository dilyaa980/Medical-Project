import React from "react";

const Treatment = () => {
  return <div></div>;
};

export default Treatment;
