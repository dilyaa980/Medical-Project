import React from "react";

const Actives = () => {
  return <div></div>;
};

export default Actives;
