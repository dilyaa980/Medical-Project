import React from "react";

const CheckUp = () => {
  return <div></div>;
};

export default CheckUp;
