import React from "react";

const Company = () => {
  return <div></div>;
};

export default Company;
