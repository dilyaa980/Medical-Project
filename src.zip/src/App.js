import React from "react";
import { Link, Routes, Route } from "react-router-dom";
import Company from "./pages/Company";
import Treatment from "./pages/Treatment";
import Beauty from "./pages/Beauty";
import CheckUp from "./pages/CheckUp";
import Medicine from "./pages/Medicine";
import Actives from "./pages/Actives";
import Contacts from "./pages/Contacts";

import Navbar from "./components/Navbar/Navbar";
import Header from "./components/Header/Header";
import Option from "./components/Option/Option";
import Directions from "./components/Directions/Directions";
import Sinchon from "./components/Sinchon/Sinchon";
import "./bootstrap-grid.css";

const App = () => {
  return (
    <div>
      <Navbar />
      <Routes>
        <Route exact path="/" element={<Company />} />
        <Route exact path="/Contacts" element={<Contacts />} />
        <Route exact path="/Treatment" element={<Treatment />} />
        <Route exact path="/Beauty" element={<Beauty />} />
        <Route exact path="/CheckUp " element={<CheckUp />} />
        <Route exact path="/Medicine" element={<Medicine />} />
        <Route exact path="/Actives" element={<Actives />} />
        <Route exact path="/Contacts" element={<Contacts />} />
       
      </Routes>
      <Header />
      <Option />
       <Routes><Route exact path="/Sinchon" element={<Sinchon />} /></Routes>
      <Directions />
      
    </div>
  );
};

export default App;
